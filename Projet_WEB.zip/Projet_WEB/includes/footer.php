<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <footer>
      <br><br><br>
      <hr>
      <p>Site créé dans le cadre du projet WEB de première année à l'ENSC - Par Juliette Gadeau et Jade Petit ❤</p>
    </footer>
  </body>
</html>
